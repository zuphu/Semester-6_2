WINDOWS

Open project in Eclipse IDE.

Referenced Libraries:
Add JUNIT jar as a referenced lib
Make sure you have the EMMA plugin installed for eclipse